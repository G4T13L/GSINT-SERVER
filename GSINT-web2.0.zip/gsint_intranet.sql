-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 12-03-2019 a las 23:34:38
-- Versión del servidor: 10.1.37-MariaDB
-- Versión de PHP: 7.3.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `gsint_intranet`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `comisiones`
--

CREATE TABLE `comisiones` (
  `id_com` int(10) NOT NULL,
  `nombre` varchar(60) NOT NULL,
  `usuario_encargado` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `comisiones`
--

INSERT INTO `comisiones` (`id_com`, `nombre`, `usuario_encargado`) VALUES
(1, 'Editora', 'yagialesandra'),
(2, 'Proyectos', 'lazaroedson'),
(3, 'Oportunidades', 'romeroandersson');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `conocimiento`
--

CREATE TABLE `conocimiento` (
  `usuario` varchar(60) NOT NULL,
  `tema` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `conocimiento`
--

INSERT INTO `conocimiento` (`usuario`, `tema`) VALUES
('sarriaeduardo', 'adb'),
('sarriaeduardo', 'ssh'),
('sarriaeduardo', 'bash'),
('sarriaeduardo', 'batch'),
('sarriaeduardo', 'web'),
('sarriaeduardo', 'xss'),
('sarriaeduardo', 'sqli'),
('anayamario', 'web'),
('anayamario', 'redes'),
('anayamario', 'hardware'),
('anayamario', 'c++'),
('leonnaro', 'r'),
('leonnaro', 'cloud'),
('sarriaeduardo', 'bypass'),
('leonnaro', 'numerico');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `contacto`
--

CREATE TABLE `contacto` (
  `usuario` varchar(60) NOT NULL,
  `telf` varchar(10) NOT NULL,
  `correo` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `contacto`
--

INSERT INTO `contacto` (`usuario`, `telf`, `correo`) VALUES
('menadaniel', '966699949', 'omenaf@uni.pe'),
('floresmanuel', '933823196', 'mflores@uni.pe'),
('serranoangela', '983439707', 'angelaserrano301@gmail.com'),
('sarriaeduardo', '949024932', 'esarriap@uni.pe'),
('poncevictor', '963354168', 'vipopi1997@gmail.con'),
('leonnaro', '925893128', 'mnleonr@uni.pe'),
('lazaroedson', '966163290', 'edsonlc_007@hotmail.com'),
('palaciosjorge', '964650248', 'jorge.palacios.a@uni.pe'),
('jimenezjoel', '971255241', 'jjimenezch@uni.pe'),
('yagialesandra', '936273111', 'harry_alesandra@hotmail.com'),
('anayamario', '943500028', 'mario.anaya.reyes@gmail.com'),
('zunigagerson', '992371799', 'zunigagerson@hotmail.com'),
('perezrenato', '977130516', 'atomsk2.0.0@gmail.com'),
('ordayaalvaro', '986946041', 'alvaro_joz2010@hotmail.com'),
('silvaitalo', '972083952', 'italosilvasg@gmail.com'),
('tuestajuan', '-----', 'jctuestaa@gmail.com'),
('chungalex', '956275113', 'alexchungalvarez@gmail.com'),
('pozodaniel', '955364956', 'julio.pozo.g@uni.pe'),
('mechanrodrigo', '944480232', 'rodrigomechan1001240@gmail.com'),
('porllesmiluska', '951380404', 'zdena160216@gmail.com'),
('kenjhybazan', '956376259', 'kbazant@uni.pe'),
('romeroandersson', '933869755', 'andromdez@gmail.com'),
('diegosalazar', '936622050', 'diegoedgardosalazarvergara@gmail.com'),
('carlosespinoza', '949174453', 'espinoza_mansilla@hotmail.com'),
('carlosmundo', '957279488', 'carlos_20128@hotmail.com'),
('andreeduenas', '959168186', 'ayrton20082009@gmail.com'),
('geraldballon', '979010454', 'asecino1999@gmail.com'),
('palaciosbrando', '951351845', 'bpalaciosm@uni.pe');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `interes`
--

CREATE TABLE `interes` (
  `usuario` varchar(60) NOT NULL,
  `tema` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `interes`
--

INSERT INTO `interes` (`usuario`, `tema`) VALUES
('sarriaeduardo', 'IA'),
('sarriaeduardo', 'bitcoins'),
('sarriaeduardo', 'redes'),
('sarriaeduardo', 'SQL'),
('sarriaeduardo', 'RFI'),
('sarriaeduardo', 'reversing'),
('sarriaeduardo', 'cloud'),
('anayamario', 'motores'),
('anayamario', 'poleas'),
('anayamario', 'laravel'),
('leonnaro', 'seguridad'),
('leonnaro', 'encriptacion'),
('leonnaro', 'esteganografia'),
('sarriaeduardo', 'blockchain'),
('leonnaro', 'teatro'),
('floresmanuel', 'u.u');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `login`
--

CREATE TABLE `login` (
  `usuario` varchar(60) NOT NULL,
  `clave` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `login`
--

INSERT INTO `login` (`usuario`, `clave`) VALUES
('menadaniel', 'menadaniel'),
('floresmanuel', 'floresmanuel'),
('serranoangela', 'serranoangela'),
('sarriaeduardo', 'sarriaeduardo'),
('poncevictor', 'poncevictor'),
('leonnaro', 'mierdaconsal'),
('lazaroedson', 'lazaroedson'),
('palaciosjorge', 'palaciosjorge'),
('jimenezjoel', 'jimenezjoel'),
('yagialesandra', 'yagialesandra'),
('anayamario', 'anayamario'),
('zunigagerson', 'zunigagerson'),
('perezrenato', 'perezrenato'),
('ordayaalvaro', 'ordayaalvaro'),
('silvaitalo', 'silvaitalo'),
('tuestajuan', 'tuestajuan'),
('chungalex', 'chungalex'),
('pozodaniel', 'pozodaniel'),
('mechanrodrigo', 'mechanrodrigo'),
('porllesmiluska', 'porllesmiluska'),
('kenjhybazan', 'kenjhybazan'),
('romeroandersson', 'romeroandersson'),
('diegosalazar', 'diegosalazar'),
('carlosespinoza', 'carlosespinoza'),
('carlosmundo', 'carlosmundo'),
('andreeduenas', 'andreeduenas'),
('geraldballon', 'geraldballon'),
('palaciosbrando', 'palaciosbrando');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario_info`
--

CREATE TABLE `usuario_info` (
  `usuario` varchar(60) NOT NULL,
  `nombre` varchar(60) NOT NULL,
  `apellido` varchar(60) NOT NULL,
  `estado` varchar(60) NOT NULL,
  `linea` varchar(60) NOT NULL,
  `id_com` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `usuario_info`
--

INSERT INTO `usuario_info` (`usuario`, `nombre`, `apellido`, `estado`, `linea`, `id_com`) VALUES
('menadaniel', 'Oscar Daniel', 'Mena Fernandez', 'Miembro Activo', 'Cableada', 1),
('floresmanuel', 'Manuel Enrique', 'Flores Farfan', 'Miembro Activo  ', 'Inalambrica', 0),
('serranoangela', 'Angela Selene', 'Serrano Sanchez', 'Miembro Activo', 'Web', 0),
('sarriaeduardo', 'Eduardo David', 'Sarria Palacios', 'Miembro Activo', 'Malware', 1),
('poncevictor', 'Victor Alberto', 'Ponce Pinedo', 'Miembro Activo', 'Forense', 0),
('leonnaro', 'Marco Naro', 'León Rios', 'Miembro Activo  ', 'Web', 1),
('lazaroedson', 'Edson Nicks', 'Lázaro Camasca', 'Miembro Activo', 'Ing.Social', 2),
('palaciosjorge', 'Jorge Gilberto', 'Palacios Asenjo', 'Miembro Activo', 'Cableada', 0),
('jimenezjoel', 'Joel Wilson', 'Jimenez Chacon', 'Miembro Activo ', 'Ing.Social', 0),
('yagialesandra', 'Gladys Alesandra', 'Yagi Vasquez', 'Miembro   ', 'Pendiente', 1),
('anayamario', 'Mario Luis', 'Anaya Reyes', 'Miembro', '-----', 0),
('zunigagerson', 'Gerson Jairo', 'Zuñiga Naquiche', 'Miembro', 'Osint', 0),
('perezrenato', 'Renato Sebastian', 'Perez Ruiz', 'Miembro', 'Osint', 0),
('ordayaalvaro', 'Alvaro Jordy', 'Ordaya Zapata', 'Colaborador   ', 'Pendiente', 0),
('silvaitalo', 'Italo Enrique', 'Silva Guanilo', 'Colaborador', 'Osint', 0),
('tuestajuan', 'Juan Carlos', 'Tuesta Llaja', 'Colaborador   ', 'Inalambrica', 0),
('chungalex', 'Alex Steve', 'Chung alvarez', 'Colaborador', 'Inalambrica', 0),
('pozodaniel', 'Julio Daniel', 'Pozo Garcia', 'Colaborador', 'Forense', 0),
('mechanrodrigo', 'Rodrigo Manuel', 'Mechan Osorio', 'Colaborador', 'Osint', 1),
('porllesmiluska', 'Miluska Zdena', 'Porlles Chavez', 'Colaborador', '-----', 1),
('kenjhybazan', 'Kenjhy Javier', 'Bazan Turin', 'Colaborador', 'Ing.Social', 0),
('romeroandersson', 'Andersson Andree', 'Romero Deza', 'Colaborador', 'Pendiente', 3),
('diegosalazar', 'Diego Edgardo', 'Salazar Vergara', 'Colaborador', 'Malware', 0),
('carlosespinoza', 'Carlos Alberto', 'Espinoza Mansilla', 'Colaborador', 'Forense', 0),
('carlosmundo', 'Carlos Rafael', 'Mundo Levano', 'Colaborador', 'Forense', 0);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
